
// to distinguish between the first
// click and the second click of two
// consecutive clicks
var first_click = true;
// the first image clicked
var first_image;
var second_image;

// if not_finished is true, there
// are still images to swao

// process the click on the image
function click_on(image) {
   if (is_finished()){
	if (first_click) {
		first_image=image;
		first_click=false;

	} else {
		second_image=image.src;
		second_image_name=image.name;

		image.src=first_image.src;
		image.name=first_image.name;

		first_image.src=second_image;
		first_image.name=second_image_name;

		first_click=true;
	}

	if (!is_finished()){
		 document.getElementById("result").style.visibility="visible";
	}
} 
}

// returns true if the puzzle is solved
function is_finished() {
	var  elt=document.getElementById("puzzle");
	var name=elt.getElementsByTagName("img");
	var name1="";
	for (var i=0; i<12; i++){
		name1=name1+name[i].name;
	}
       
     if (name1=="abcdefghijkl"){
     	
	     return false;
        } 
     else {
     	return true } 

}
