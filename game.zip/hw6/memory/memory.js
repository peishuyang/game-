
var img1;
var img2;
var n1;

// the array of the path of the images
var array = [];

// if clicked[i] is true, array[i] if visible
var clicked = [];

// to distinguish between the first
// click and the second click of two
// consecutive clicks
var first_click = true;

// the index in the array of the first image clicked
var first_index = 0;

// the total number of pairs of clicks
var clicks_number = 0;

// the number of good paors of clicks
// (i.e. clicks which revealed two identical images)
var good_clicks_number = 0;

// change the content of the attribute src of the two
// images at index i and j to the question mark image
function hide(i, j) {
  document.images[i].src="question-mark.png";
  document.images[j].src="question-mark.png";

}

// process the click on image at index n
function click_image(n) {	
	//alert(good_clicks_number);
if (good_clicks_number==8) {
	    re=document.getElementById("result");
	    re.style.visibility="visible";
	    re.innerHTML="You uses  " + clicks_number + "  steps !! ";
    
  }  else {

    if (first_click) {
    	clicks_number=clicks_number+1;
    	n1=n;
    	img1=document.images[n];
    	img1.src=img1.name;
		first_click=false;
	}
	else {
		img2=document.images[n];		
		if (img2.name!=img1.name){

			img2.src=img2.name;
			setTimeout(hide,300,n1,n);			
		} else {
			good_clicks_number=good_clicks_number+1;

			img2.src=img2.name;
		}
        first_click=true;
	}
}
}

// fill the array with the content of the name
// attribute of the images
function fill_array() {

}

// to fill the array before the game starts
window.onload = fill_array;

